from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd

def setup_driver(headless=False):
    options = Options()
    if headless:
        options.add_argument("--headless")
    options.add_argument("--disable-gpu")
    options.add_argument("--window-size=1920,1080")
    return webdriver.Chrome(options=options)

def scrape_top250():
    driver = setup_driver()
    url = "https://www.imdb.com/chart/top/"
    driver.get(url)
    print("✅ IMDb Top 250 page loaded successfully.")

    # Optional: Save screenshot for debugging
    driver.save_screenshot("imdb_debug.png")

    movie_data = []

    try:
        # Wait for the table to load
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "div.ipc-page-content-container"))
        )
        rows = driver.find_elements(By.CSS_SELECTOR, "div.ipc-page-content-container ul li")
        print(f"🔍 Found {len(rows)} movie entries.")

        for row in rows:
            try:
                title_elem = row.find_element(By.CSS_SELECTOR, "h3")
                rating_elem = row.find_element(By.CSS_SELECTOR, "span.ipc-rating-star")
                title = title_elem.text
                rating = rating_elem.text
                movie_data.append({"Title": title, "Rating": rating})
                print(f"{title} — ⭐ {rating}")
            except Exception:
                continue

    except Exception as e:
        print("❌ Failed to load movie elements:", e)

    driver.quit()
    return movie_data

def save_to_csv(data, filepath):
    df = pd.DataFrame(data)
    df.to_csv(filepath, index=False)

def main():
    data = scrape_top250()
    if data:
        save_to_csv(data, "imdb_top250.csv")
        print(f"\n📁 Saved {len(data)} movies to imdb_top250.csv")
    else:
        print("⚠️ No data scraped.")

if __name__ == "__main__":
    main()