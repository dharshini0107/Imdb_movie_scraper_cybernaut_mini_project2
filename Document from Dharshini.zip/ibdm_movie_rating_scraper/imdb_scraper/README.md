# 🎬 IMDb Top 250 Scraper

A Python mini project that scrapes IMDb's Top 250 movies using Selenium, saves them to a CSV file, and displays them with colorful console output and an ASCII banner.

## Features
- Scrapes movie titles and ratings
- Saves data to `imdb_top250.csv`
- Colorful terminal output with `colorama`
- ASCII banner with `pyfiglet`
- Modular code structure

## Setup
1. Install dependencies:
2. Download:
- [Chrome for Testing](https://googlechromelabs.github.io/chrome-for-testing/)
- [ChromeDriver](https://googlechromelabs.github.io/chrome-for-testing/#stable)

3. Update paths in `top250_scraper.py`:
```python
options.binary_location = "your/path/to/chrome.exe"
service = Service("your/path/to/chromedriver.exe")
