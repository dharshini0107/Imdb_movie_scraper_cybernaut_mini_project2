from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import pandas as pd
from colorama import Fore, Style
from pyfiglet import figlet_format

def setup_driver(headless=False):
    options = Options()
    if headless:
        options.add_argument("--headless")
    options.add_argument("--disable-gpu")
    options.add_argument("--window-size=1920,1080")
    return webdriver.Chrome(options=options)

def save_to_csv(data, filepath):
    df = pd.DataFrame(data)
    df.to_csv(filepath, index=False)

def print_banner():
    banner = figlet_format("IMDb Scraper")
    print(Fore.CYAN + banner + Style.RESET_ALL)