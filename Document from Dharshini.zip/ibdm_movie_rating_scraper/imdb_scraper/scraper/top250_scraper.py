from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def scrape_top250():
    options = webdriver.ChromeOptions()
    options.binary_location = "C:/Users/dhars/Downloads/chrome-win64/chrome-win64/chrome.exe"
    service = Service("C:/Users/dhars/Downloads/chromedriver-win64/chromedriver-win64/chromedriver.exe")
    driver = webdriver.Chrome(service=service, options=options)

    url = "https://www.imdb.com/chart/top/"
    driver.get(url)
    print("✅ IMDb Top 250 page loaded successfully.")

    movie_data = []

    try:
        rows = WebDriverWait(driver, 20).until(
            EC.presence_of_all_elements_located((By.CSS_SELECTOR, "tbody tr"))
        )
        print(f"🔍 Found {len(rows)} movie rows.")

        for row in rows:
            try:
                title = row.find_element(By.CSS_SELECTOR, "td.titleColumn a").text
                rating = row.find_element(By.CSS_SELECTOR, "td.imdbRating strong").text
                movie_data.append([title, rating])
            except Exception:
                continue

    except Exception as e:
        print("❌ Failed to load movie elements:", e)

    driver.quit()
    return movie_data